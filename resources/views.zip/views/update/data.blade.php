@extends('layouts.master')
@section('title'){{trans_choice('general.update',2)}}
@endsection
@section('content')
<div class="box box-default">
    <div class="box-header with-border">
        <h3 class="box-title">{{trans_choice('general.update',2)}}</h3>

        <div class="box-tools pull-right">

        </div>
    </div>
    <div class="box-body">

    </div>
    <!-- /.box-body -->

</div>
<!-- /.box -->
@endsection
